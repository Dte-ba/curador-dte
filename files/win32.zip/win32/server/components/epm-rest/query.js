'use strict';

var _ = require('lodash');

var manager = require('../epm-manager');

var transformQuery = function transformQuery(part) {

  if (_.isArray(part)) {
    var a = [];
    part.forEach(function (p) {
      a.push(transformQuery(p));
    });
    return a;
  }

  var q = {};

  _.forIn(part, function (value, key) {
    if (key === '$in') {
      q[key] = value;
    } else if (_.isObject(value) || _.isArray(value)) {
      q[key] = transformQuery(value);
    } else if (key === '$regex') {
      q[key] = new RegExp(value, 'ig');
    } else {
      q[key] = value;
    }
  });

  return q;
};

function filterQuery(text, items, res) {
  var scaped = _.deburr(_.trim(text));

  var isDistrito = /^area\s+[\w+\s]+$/ig;
  var clean = /^(area)\s+/ig;
  var to = text.replace(clean, '');

  var res = [];

  if (res.length === 0) {
    return [{ caption: 'Buscar ' + text }];
  }

  return [];
}

module.exports = {

  query: function query(req, res, next) {
    var rname = req.params.repository;

    manager.get(rname).progress(function (info) {}).fail(function (err) {
      next(err);
    }).done(function (repo) {
      if (req.body.searchtext !== undefined) {
        repo.find({}, function (err, items) {
          if (err) {
            return next(err);
          }

          res.json(filterQuery(req.body.searchtext, items, res));
        });
      } else {
        var q = transformQuery(req.body);
        repo.find(q, function (err, items) {
          if (err) {
            return next(err);
          }
          res.json(items);
        });
      }
    });
  },
  queryp: function queryp(req, res, next) {
    var rname = req.params.repository;

    manager.get(rname).progress(function (info) {}).fail(function (err) {
      next(err);
    }).done(function (repo) {
      var qobj = req.body;

      var q = transformQuery(qobj.query);
      var take = qobj.take;
      var skip = qobj.skip;

      repo.find(q, function (err, items) {
        if (err) {
          return next(err);
        }
        var total = items.length;
        if (take !== undefined && skip !== undefined) {
          var taked = _(items).slice(skip, skip + take).value();

          //console.log('items.length ', taked.length);
          //console.log('skip ', skip);
          //console.log('take ', take);

          res.json({ items: taked, total: total, skip: skip });
        } else {
          res.json({ items: items, total: total, take: take });
        }
      });
    });
  }

};
//# sourceMappingURL=query.js.map
