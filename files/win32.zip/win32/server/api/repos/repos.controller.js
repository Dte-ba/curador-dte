/**
 * Using Rails-like standard naming convention for endpoints.
 * GET     /api/things              ->  index
 */

'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.index = index;
var manager = require('../../components/epm-manager');
var _ = require('lodash');

// Gets a list of Things
function index(req, res, next) {

  manager.getRepos(function (err, repos) {
    if (err) {
      return next(err);
    }

    res.json(_.map(repos, function (r) {
      return { name: r.name };
    }));
  });
}
//# sourceMappingURL=repos.controller.js.map
