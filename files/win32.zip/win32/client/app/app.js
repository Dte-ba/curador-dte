'use strict';

angular.module('epmApp', ['epmApp.constants', 'ngCookies', 'ngResource', 'ngSanitize', 'ngAnimate', 'ngAria', 'ngMaterial', 'ui.router', 'ngDropzone']).config(function ($urlRouterProvider, $locationProvider, $mdThemingProvider) {
  $urlRouterProvider.otherwise('/');

  $locationProvider.html5Mode(true);

  $mdThemingProvider.definePalette('bagrey', {
    '50': '#e9eaea',
    '100': '#c2c3c5',
    '200': '#a6a7a9',
    '300': '#818486',
    '400': '#727477',
    '500': '#636567',
    '600': '#545657',
    '700': '#454648',
    '800': '#363738',
    '900': '#272829',
    'A100': '#e9eaea',
    'A200': '#c2c3c5',
    'A400': '#727477',
    'A700': '#454648',
    'contrastDefaultColor': 'light',
    'contrastDarkColors': '50 100 200 300 A100 A200'
  });

  $mdThemingProvider.definePalette('bagreen', {
    '50': '#eff7da',
    '100': '#d3e99c',
    '200': '#bfdf6e',
    '300': '#a5d233',
    '400': '#94bd2a',
    '500': '#80a424',
    '600': '#6c8b1e',
    '700': '#597219',
    '800': '#455913',
    '900': '#32400e',
    'A100': '#eff7da',
    'A200': '#d3e99c',
    'A400': '#94bd2a',
    'A700': '#597219',
    'contrastDefaultColor': 'light',
    'contrastDarkColors': '50 100 200 300 400 500 A100 A200 A400'
  });

  $mdThemingProvider.theme('default').primaryPalette('bagrey').accentPalette('bagreen');
}).run(function ($rootScope) {
  $rootScope._repo = 'local';
  $rootScope._repositories = ['local'];
});
//# sourceMappingURL=app.js.map

'use strict';

angular.module('epmApp.util', []);
//# sourceMappingURL=util.module.js.map

'use strict';

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function () {
  var AgregarComponent = function AgregarComponent($log) {
    _classCallCheck(this, AgregarComponent);

    this.message = 'Hello';

    this.dzAddedFile = function (file) {
      $log.log(file);
    };

    this.dzError = function (file, errorMessage) {
      $log.log(errorMessage);
    };

    this.dropzoneConfig = {
      parallelUploads: 1,
      maxFileSize: 30
    };
  };

  angular.module('epmApp').component('agregar', {
    templateUrl: 'app/agregar/agregar.html',
    controller: AgregarComponent,
    controllerAs: 'vm'
  });
})();
//# sourceMappingURL=agregar.controller.js.map

'use strict';

angular.module('epmApp').config(function ($stateProvider) {
  $stateProvider.state('agregar', {
    url: '/agregar',
    template: '<agregar></agregar>'
  });
});
//# sourceMappingURL=agregar.js.map

"use strict";

(function (angular, undefined) {
	angular.module("epmApp.constants", []).constant("appConfig", {
		"userRoles": ["guest", "user", "admin"]
	});
})(angular);
//# sourceMappingURL=app.constant.js.map

'use strict';

angular.module('epmApp').directive('delayedModel', function () {
  return {
    scope: {
      model: '=delayedModel'
    },
    link: function link(scope, element, attrs) {

      element.val(scope.model);

      scope.$watch('model', function (newVal, oldVal) {
        if (newVal !== oldVal) {
          element.val(scope.model);
        }
      });

      var timeout;
      element.on('keyup paste search', function () {
        clearTimeout(timeout);
        timeout = setTimeout(function () {
          scope.model = element[0].value;
          element.val(scope.model);
          scope.$apply();
        }, attrs.delay || 500);
      });
    }
  };
});
//# sourceMappingURL=common.directives.js.map

'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function () {
  var MainController = function () {
    function MainController($scope, $http, $rootScope, $mdToast, $mdMedia, $mdDialog, $stateParams) {
      _classCallCheck(this, MainController);

      this.$http = $http;
      this.$rootScope = $rootScope;
      this.working = true;
      this.$mdToast = $mdToast;
      this.$mdMedia = $mdMedia;
      this.$scope = $scope;
      this.$mdDialog = $mdDialog;

      this.$stateParams = $stateParams;
      this.searchText = $stateParams.buscar;

      this.medias = [
      // '(max-width: 599px)'
      { media: 'xs', columns: 1 },
      //{ media: 'gt-xs', caption: '(min-width: 600px)' },
      // '(min-width: 600px) and (max-width: 959px)'
      { media: 'sm', columns: 2 },
      //{ media: 'gt-sm', caption: '(min-width: 960px)' },
      // '(min-width: 960px) and (max-width: 1279px)'
      { media: 'md', columns: 3 },
      //{ media: 'gt-md', caption: '(min-width: 1280px)' },
      // '(min-width: 1280px) and (max-width: 1919px)'
      { media: 'lg', columns: 4 },
      //{ media: 'gt-lg', caption: '(min-width: 1920px)' },
      // '(min-width: 1920px)
      { media: 'xl', columns: 5 }];
    }

    _createClass(MainController, [{
      key: 'mapItem',
      value: function mapItem(item) {
        var ct = item.content;
        var tags = _.map(ct.tags.split(','), _.trim);

        var icons = {
          'Técnica': 'fa-cog',
          'Administrativa': 'fa-archive',
          'Pedadógica': 'fa-book',
          'DTE': 'fa-rocket'
        };

        return {
          uid: item.uid,
          area: ct.area,
          axis: ct.axis,
          block: ct.block,

          deburr_area: _.deburr(ct.area),
          deburr_axis: _.deburr(ct.axis),
          deburr_block: _.deburr(ct.block),

          front: '/epm/asset/local/' + item.uid + '/cover/front',
          cover: '/epm/asset/local/' + item.uid + '/cover/content',
          tags: tags,
          content: ct.content,
          title: ct.title,
          autor: ct.autor,
          icon: icons[ct.area]
        };
      }
    }, {
      key: 'refresh',
      value: function refresh(media) {
        var _this = this;

        //console.log(media);
        this.columns = [];
        // create columns
        for (var c = 0; c < media.columns; c++) {
          this.columns.push([]);
        }

        var chunked = _.chunk(this.packages, media.columns);

        _.each(chunked, function (items) {
          for (var c = 0; c < media.columns; c++) {
            if (items[c] !== undefined) {
              _this.columns[c].push(items[c]);
            }
          }
        });

        //console.log(this.columns);
      }
    }, {
      key: '$onInit',
      value: function $onInit() {
        var _this2 = this;

        var q = {};

        if (this.searchText && this.searchText !== '') {
          var trimTexto = _.trim(this.searchText);
          //var texto = _.deburr(trimTexto);
          var texto = trimTexto;
          texto = _.escapeRegExp(texto.toLowerCase());

          q = {
            $or: [{ 'content.tags': { $regex: texto } }, { 'content.area': { $regex: texto } }, { 'content.axis': { $regex: texto } }, { 'content.block': { $regex: texto } }, { 'content.content': { $regex: texto } }, { 'content.title': { $regex: texto } }, { 'uid': { $regex: texto } }]
          };
        }

        this.$http.post('/epm/query/' + this.$rootScope._repo, q).then(function (res) {
          _this2.packages = _.map(res.data, function (d) {
            return _this2.mapItem(d);
          });

          _this2.working = false;
          _this2.grouped = _.chunk(_this2.packages, 2);

          _.each(_this2.medias, function (m) {

            _this2.$scope.$watch(function () {
              return _this2.$mdMedia(m.media);
            }, function (value) {
              if (value) {
                _this2.refresh(m);
              }
            });
          });
        }).catch(function (err) {
          _this2.working = false;
        });
      }
    }, {
      key: 'show',
      value: function show(ev, item) {
        this.$mdDialog.show({
          controller: DialogController,
          templateUrl: 'app/main/package.tmpl.html',
          parent: angular.element(document.body),
          targetEvent: ev,
          clickOutsideToClose: true,
          locals: { item: item }
          //fullscreen: $scope.customFullscreen // Only for -xs, -sm breakpoints.
        }).then(function (answer) {
          //$scope.status = 'You said the information was "' + answer + '".';
        }, function () {
          //$scope.status = 'You cancelled the dialog.';
        });
      }
    }, {
      key: 'getPackages',
      value: function getPackages() {
        return _.chunk(this.packages, 5);
      }
    }]);

    return MainController;
  }();

  function DialogController($scope, $mdDialog, item) {

    $scope.item = item;

    $scope.hide = function () {
      $mdDialog.hide();
    };

    $scope.cancel = function () {
      $mdDialog.cancel();
    };

    $scope.answer = function (answer) {
      $mdDialog.hide(answer);
    };

    $scope.$onInit = function () {};
  }

  angular.module('epmApp').component('main', {
    templateUrl: 'app/main/main.html',
    controller: MainController,
    controllerAs: 'vm'
  });
})();
//# sourceMappingURL=main.controller.js.map

'use strict';

angular.module('epmApp').config(function ($stateProvider) {
  $stateProvider.state('main', {
    url: '/?buscar',
    template: '<main></main>'
  });
});
//# sourceMappingURL=main.js.map

'use strict';

angular.module('epmApp').directive('footer', function () {
  return {
    templateUrl: 'components/footer/footer.html',
    restrict: 'E',
    link: function link(scope, element) {
      element.addClass('footer');
    }
  };
});
//# sourceMappingURL=footer.directive.js.map

'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var NavbarController = function () {
  function NavbarController($http, $rootScope, $state) {
    _classCallCheck(this, NavbarController);

    this.$http = $http;
    this.$rootScope = $rootScope;
    this.$state = $state;

    this.working = true;

    this.isDisabled = false;
    this.noCache = false;
    this.selectedItem;
    this.searchText = '';
  }

  _createClass(NavbarController, [{
    key: '$onInit',
    value: function $onInit() {}
  }, {
    key: 'selectedItemChange',
    value: function selectedItemChange(item) {
      var text = '';
      if (item) {
        text = item.text || '';
      }
      this.$state.go('main', { buscar: text });
    }
  }, {
    key: 'querySearch',
    value: function querySearch(text) {
      if (text === '') {
        return [];
      }
      return [{ caption: 'Buscar ' + text, text: text }];
    }
  }]);

  return NavbarController;
}();

angular.module('epmApp').controller('NavbarController', NavbarController);
//# sourceMappingURL=navbar.controller.js.map

'use strict';

angular.module('epmApp').directive('navbar', function () {
  return {
    templateUrl: 'components/navbar/navbar.html',
    restrict: 'E',
    controller: 'NavbarController',
    controllerAs: 'nav'
  };
});
//# sourceMappingURL=navbar.directive.js.map

'use strict';

(function () {

  /**
   * The Util service is for thin, globally reusable, utility functions
   */
  function UtilService($window) {
    var Util = {
      /**
       * Return a callback or noop function
       *
       * @param  {Function|*} cb - a 'potential' function
       * @return {Function}
       */
      safeCb: function safeCb(cb) {
        return angular.isFunction(cb) ? cb : angular.noop;
      },


      /**
       * Parse a given url with the use of an anchor element
       *
       * @param  {String} url - the url to parse
       * @return {Object}     - the parsed url, anchor element
       */
      urlParse: function urlParse(url) {
        var a = document.createElement('a');
        a.href = url;

        // Special treatment for IE, see http://stackoverflow.com/a/13405933 for details
        if (a.host === '') {
          a.href = a.href;
        }

        return a;
      },


      /**
       * Test whether or not a given url is same origin
       *
       * @param  {String}           url       - url to test
       * @param  {String|String[]}  [origins] - additional origins to test against
       * @return {Boolean}                    - true if url is same origin
       */
      isSameOrigin: function isSameOrigin(url, origins) {
        url = Util.urlParse(url);
        origins = origins && [].concat(origins) || [];
        origins = origins.map(Util.urlParse);
        origins.push($window.location);
        origins = origins.filter(function (o) {
          var hostnameCheck = url.hostname === o.hostname;
          var protocolCheck = url.protocol === o.protocol;
          // 2nd part of the special treatment for IE fix (see above):  
          // This part is when using well-known ports 80 or 443 with IE,
          // when $window.location.port==='' instead of the real port number.
          // Probably the same cause as this IE bug: https://goo.gl/J9hRta
          var portCheck = url.port === o.port || o.port === '' && (url.port === '80' || url.port === '443');
          return hostnameCheck && protocolCheck && portCheck;
        });
        return origins.length >= 1;
      }
    };

    return Util;
  }

  angular.module('epmApp.util').factory('Util', UtilService);
})();
//# sourceMappingURL=util.service.js.map

angular.module("epmApp").run(["$templateCache", function($templateCache) {$templateCache.put("app/agregar/agregar.html","<form class=\"dropzone\"\n        action=\"/upload\" \n        method=\"post\"\n        enctype=\"multipart/form-data\"\n        ng-dropzone\n        dropzone=\"vm.dropzone\"\n        dropzone-config=\"vm.dropzoneConfig\"\n        event-handlers=\"{ \'addedfile\': vm.dzAddedFile, \'error\': vm.dzError }\">\n  </form>\n\n\n<a ui-sref=\"main\" class=\"buttonFixed\" md-whiteframe=\"24\"><md-button class=\"md-fab\" aria-label=\"\" >\n  <md-tooltip md-direction=\"top\">Volver</md-tooltip>\n  <md-icon md-font-icon=\"fa-check\" class=\"fa\"></md-icon>\n</md-button></a>\n");
$templateCache.put("app/main/main.html","<div layout=\"column\" flex layout-fill >\n  <md-progress-circular md-mode=\"indeterminate\" ng-show=\"vm.working\"></md-progress-circular>\n  \n  <md-content layout-padding\n              layout=\"row\"\n              layout-align=\"center top\"\n              class=\"content package\">\n\n      <div flex layout=\"column\" ng-repeat=\"rows in vm.columns\">\n        <md-card ng-repeat=\"item in rows\">\n          <!--<md-card-header>\n              <md-card-header-text>\n                <span class=\"md-title\"><small>{{item.title}}</small></span>\n                <span class=\"md-title\">{{item.block}}</span>\n                <span class=\"md-subhead\">{{item.area}} - {{item.axis}}</span>\n              </md-card-header-text>\n          </md-card-header>-->\n          <md-divider></md-divider>\n          <img ng-src=\"{{item.front}}\" class=\"md-card-image\" alt=\"Cover\">\n          <div layout=\"row\" class=\"button-under-image\">\n            <span flex></span>\n            <md-button class=\"md-fab bg-area\" aria-label=\"\" ng-click=\"vm.show($event, item)\"\n                       target-area=\"{{item.area}}\">\n              <md-tooltip md-direction=\"top\">Abrir</md-tooltip>\n              <md-icon md-font-icon=\"{{item.icon}}\" class=\"fa fa-lg\"></md-icon>\n            </md-button>\n          </div>\n          <md-card-title>\n            <md-card-title-text>\n              <span class=\"md-headline\">{{item.title}}</span>\n              <div layout=\"column\" class=\"card-categories\">\n                <div class=\"title-area\">\n                  <a ui-sref=\"main({ buscar: item.area })\" class=\"link-nodecorate\">{{item.area}}</a>\n                </div>\n                <div layout=\"row\">\n                  <div class=\"title-chevron\"><i class=\"fa fa-angle-right fa-2x\"></i></div>\n                  <div flex>\n                    <div class=\"title-axis\">\n                      <a ui-sref=\"main({ buscar: item.axis })\" class=\"link-nodecorate\">{{item.axis}}</a>\n                      </div>\n                    <div class=\"title-block\" ng-if=\"item.block !== \'Sin Especificar\'\">\n                      <a ui-sref=\"main({ buscar: item.block })\" class=\"link-nodecorate\">{{item.block}}\n                      </a>\n                      </div>\n                  </div>\n                </div>\n              </div>\n            </md-card-title-text>\n          </md-card-title>\n          <md-card-content>\n          </md-card-content>\n          <!--<md-card-actions layout=\"row\" layout-align=\"end center\">\n            \n          </md-card-actions>-->\n        </md-card>\n      </div>\n    \n  </md-content>\n</div>");
$templateCache.put("app/main/package.tmpl.html","<md-dialog aria-label=\"Mango (Fruit)\">\n  <form ng-cloak>\n    <md-toolbar>\n      <div class=\"md-toolbar-tools\">\n        <h2>{{item.title}}</h2>\n        <span flex></span>\n        <md-button class=\"md-icon-button\" ng-click=\"cancel()\">\n          <md-icon md-font-icon=\"fa-times\" class=\"fa\"></md-icon>   \n        </md-button>\n      </div>\n    </md-toolbar>\n\n    <md-dialog-content>\n\n      <div class=\"md-dialog-content\" layout=\"row\" layout-sm=\"column\" layout-padding>\n        <div flex>\n          <img style=\"margin: auto; max-width: 100%;\" alt=\"Lush mango tree\" ng-src=\"{{item.cover}}\">\n        </div>\n        <div flex layout=\"column\">\n          <div flex>\n            <h3><i class=\"fa fa-info-circle\"></i> Ficha Técnica</h3>\n            <p>{{item.content}}</p>\n            <md-divider></md-divider>\n          </div>\n          <div flex layout=\"column\">\n            <span flex></span>\n            <md-button class=\"md-raised md-primary\" target=\"_blank\"\n                       ng-href=\"/epm/content/{{$parent._repo}}/{{item.uid}}\">Acceder al Material</md-button> \n          </div>\n        </div>\n      </div>\n    </md-dialog-content>\n    <md-dialog-actions layout=\"row\">\n      <div><i class=\"fa fa-tag fa-2x\"></i></div>\n      <div flex>\n        <ul class=\"tangible-tags\">\n          <li ng-repeat=\"tag in item.tags\">\n            <a ui-sref=\"main({ buscar: tag })\">{{tag}}</a>\n          </li>\n        </ul>\n      </div>\n    </md-dialog-actions>\n  </form>\n</md-dialog>");
$templateCache.put("components/footer/footer.html","");
$templateCache.put("components/navbar/navbar.html","<md-toolbar layout=\"row\" class=\"md-toolbar-tools\" md-scroll-shrink>\n  <md-button class=\"menu md-icon-button\" hide-gt-sm ng-click=\"_toggleList()\"\n             aria-label=\"{{_ariaLabel}}\">\n    <i class=\"fa fa-navicon\"></i>\n  </md-button>\n  <img class=\"logo-toolbar\" ng-src=\"/assets/images/dte_tablero_logo-957b7d7aea.png\"><h1> Tablero</h1>\n  <span flex></span>\n  <md-autocomplete\n      flex=\"50\"\n      ng-disabled=\"nav.isDisabled\"\n      md-no-cache=\"nav.noCache\"\n      md-selected-item=\"nav.selectedItem\"\n      md-search-text-change=\"nav.searchTextChange(nav.searchText)\"\n      md-search-text=\"nav.searchText\"\n      md-selected-item-change=\"nav.selectedItemChange(item)\"\n      md-items=\"item in nav.querySearch(nav.searchText)\"\n      md-item-text=\"item.text\"\n      md-min-length=\"0\"\n      placeholder=\"Buscar\"\n      md-menu-class=\"autocomplete-custom-template\"\n      >\n    <md-item-template>\n      <span class=\"item-title\">\n        <i class=\"fa\" ng-class=\"item.icon\"></i>\n        <span> {{item.caption}} </span>\n      </span>\n      <span class=\"item-metadata\">\n        <span class=\"item-metastat\" ng-repeat=\"meta in item.metastats\">\n          <small><i class=\"fa\" ng-class=\"meta.icon\"></i> <strong>{{meta.total}}</strong> {{meta.caption}}</small>\n        </span>\n      </span>\n    </md-item-template>\n  </md-autocomplete>\n\n  <a ui-sref=\"agregar\">\n    <md-button >\n      <md-icon md-font-icon=\"fa-upload\" class=\"fa\"></md-icon>\n    </md-button>\n  </a>\n  \n  <!--<md-menu md-position-mode=\"target-right target\" >\n    <md-button ng-click=\"$mdOpenMenu($event)\">\n      <md-tooltip>Repositorios</md-tooltip>\n      <i class=\"fa fa-code-fork\"></i> {{_repo | uppercase}}\n    </md-button>\n    <md-menu-content width=\"3\" >\n      <md-menu-item ng-repeat=\"item in _repositories\">\n        <md-button ng-click=\"nav.changeRepo(item)\">\n        {{item | uppercase}}\n        </md-button>\n      </md-menu-item>\n    </md-menu-content>\n  </md-menu>-->\n</md-toolbar>");}]);